# Spring-Specification-Example
Example app for my blogpost https://leaks.wanari.com/2018/01/23/awesome-spring-specification
