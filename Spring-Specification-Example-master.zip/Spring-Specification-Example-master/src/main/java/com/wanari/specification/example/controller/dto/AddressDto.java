package com.wanari.specification.example.controller.dto;

public class AddressDto {
    public Long id;
    public Integer zip;
    public String street;
    public String city;
}
