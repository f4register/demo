package com.wanari.specification.example.service.errors;

public class ErrorResponse {
    public int status;
}
