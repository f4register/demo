package com.wanari.specification.example;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpecificationExampleApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpecificationExampleApplication.class, args);
    }
}
