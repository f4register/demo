INSERT INTO trade (product, portfolio, trade_id, book, submitter_id, submitter_deal_id, deal_type, bid_type, current_value, previous_value) 
values('Palm Oil','Aggressive',1,908,7123,5829,'Physical','Buy',1529,358);
INSERT INTO trade (product, portfolio, trade_id, book, submitter_id, submitter_deal_id, deal_type, bid_type, current_value, previous_value)
values('Rubber','Defensive',2,1118,6008,7323,'Financial','Sell',118,226);
INSERT INTO trade (product, portfolio, trade_id, book, submitter_id, submitter_deal_id, deal_type, bid_type, current_value, previous_value)
values('Wool','Income',3,1703,5643,5049,'Physical','Buy',1907,1442);
INSERT INTO trade (product, portfolio, trade_id, book, submitter_id, submitter_deal_id, deal_type, bid_type, current_value, previous_value)
values('Amber','Speculative',4,1359,7196,4085,'Financial','Sell',1695,1637);
INSERT INTO trade (product, portfolio, trade_id, book, submitter_id, submitter_deal_id, deal_type, bid_type, current_value, previous_value)
values('Copper','Hybrid',5,1245,5888,1922,'Physical','Buy',408,1950);
INSERT INTO trade (product, portfolio, trade_id, book, submitter_id, submitter_deal_id, deal_type, bid_type, current_value, previous_value)
values('Lead','Aggressive',6,55,4523,9072,'Financial','Sell',1572,1846);
INSERT INTO trade (product, portfolio, trade_id, book, submitter_id, submitter_deal_id, deal_type, bid_type, current_value, previous_value)
values('Zinc','Defensive',7,841,923,1150,'Physical','Buy',1337,130);
INSERT INTO trade (product, portfolio, trade_id, book, submitter_id, submitter_deal_id, deal_type, bid_type, current_value, previous_value)
values('Tin','Income',8,641,3043,2284,'Financial','Sell',1884,1792);
INSERT INTO trade (product, portfolio, trade_id, book, submitter_id, submitter_deal_id, deal_type, bid_type, current_value, previous_value)
values('Aluminium','Speculative',9,730,1462,2218,'Physical','Buy',1412,363);
INSERT INTO trade (product, portfolio, trade_id, book, submitter_id, submitter_deal_id, deal_type, bid_type, current_value, previous_value)
values('Aluminium Alloy','Hybrid',10,1092,3412,3825,'Financial','Sell',1776,1135);
INSERT INTO trade (product, portfolio, trade_id, book, submitter_id, submitter_deal_id, deal_type, bid_type, current_value, previous_value)
values('Nickel','Aggressive',11,412,1419,4675,'Physical','Buy',1501,776);
INSERT INTO trade (product, portfolio, trade_id, book, submitter_id, submitter_deal_id, deal_type, bid_type, current_value, previous_value)
values('Cobalt','Defensive',12,1308,9100,9300,'Financial','Sell',292,1795);
INSERT INTO trade (product, portfolio, trade_id, book, submitter_id, submitter_deal_id, deal_type, bid_type, current_value, previous_value)
values('Molybdenum','Income',13,678,2341,5297,'Physical','Buy',743,555);
INSERT INTO trade (product, portfolio, trade_id, book, submitter_id, submitter_deal_id, deal_type, bid_type, current_value, previous_value)
values('Recycled Steel','Speculative',14,1218,4186,2206,'Financial','Sell',366,1055);
INSERT INTO trade (product, portfolio, trade_id, book, submitter_id, submitter_deal_id, deal_type, bid_type, current_value, previous_value)
values('Corn','Hybrid',15,194,8960,5412,'Physical','Buy',1683,1683);
INSERT INTO trade (product, portfolio, trade_id, book, submitter_id, submitter_deal_id, deal_type, bid_type, current_value, previous_value)
values('Oats','Aggressive',16,1249,9072,4779,'Financial','Sell',1597,1697);
INSERT INTO trade (product, portfolio, trade_id, book, submitter_id, submitter_deal_id, deal_type, bid_type, current_value, previous_value)
values('Rough Rice','Defensive',17,1477,2438,1359,'Physical','Buy',90,1461);
INSERT INTO trade (product, portfolio, trade_id, book, submitter_id, submitter_deal_id, deal_type, bid_type, current_value, previous_value)
values('Soybeans','Income',18,1448,6276,272,'Financial','Sell',909,1878);
INSERT INTO trade (product, portfolio, trade_id, book, submitter_id, submitter_deal_id, deal_type, bid_type, current_value, previous_value)
values('Rapeseed','Speculative',19,154,5821,8748,'Physical','Buy',1615,619);
INSERT INTO trade (product, portfolio, trade_id, book, submitter_id, submitter_deal_id, deal_type, bid_type, current_value, previous_value)
values('Soybean Meal','Hybrid',20,1857,2943,1074,'Financial','Sell',298,1194);
INSERT INTO trade (product, portfolio, trade_id, book, submitter_id, submitter_deal_id, deal_type, bid_type, current_value, previous_value)
values('Soybean Oil','Aggressive',21,341,7269,1134,'Physical','Buy',1860,1392);
INSERT INTO trade (product, portfolio, trade_id, book, submitter_id, submitter_deal_id, deal_type, bid_type, current_value, previous_value)
values('Wheat','Defensive',22,1161,2998,284,'Financial','Sell',778,937);
INSERT INTO trade (product, portfolio, trade_id, book, submitter_id, submitter_deal_id, deal_type, bid_type, current_value, previous_value)
values('Milk','Income',23,1006,1590,6197,'Physical','Buy',793,161);
INSERT INTO trade (product, portfolio, trade_id, book, submitter_id, submitter_deal_id, deal_type, bid_type, current_value, previous_value)
values('Coca','Speculative',24,1650,5223,1642,'Financial','Sell',589,1828);
INSERT INTO trade (product, portfolio, trade_id, book, submitter_id, submitter_deal_id, deal_type, bid_type, current_value, previous_value)
values('Coffee C','Hybrid',25,1322,4257,2924,'Physical','Buy',1740,847);
INSERT INTO trade (product, portfolio, trade_id, book, submitter_id, submitter_deal_id, deal_type, bid_type, current_value, previous_value)
values('Cotton No.2','Aggressive',26,214,8139,511,'Financial','Sell',1708,1064);
INSERT INTO trade (product, portfolio, trade_id, book, submitter_id, submitter_deal_id, deal_type, bid_type, current_value, previous_value)
values('Sugar No.11','Defensive',27,455,5641,1628,'Physical','Buy',1578,826);
INSERT INTO trade (product, portfolio, trade_id, book, submitter_id, submitter_deal_id, deal_type, bid_type, current_value, previous_value)
values('Sugar No.14','Income',28,1720,9457,2099,'Financial','Sell',1517,1570);
