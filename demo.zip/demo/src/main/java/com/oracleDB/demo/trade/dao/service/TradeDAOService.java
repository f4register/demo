package com.oracleDB.demo.trade.dao.service;

import java.io.Console;
import java.util.Comparator;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.ParameterExpression;
import javax.persistence.criteria.Root;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;
import org.springframework.stereotype.Repository;

import com.oracleDB.demo.trade.entity.Trade;

import ch.qos.logback.classic.Logger;

@Repository
public class TradeDAOService {

	private static EntityManagerFactory entityManagerFactory =
	          Persistence.createEntityManagerFactory("test");
	private EntityManager em;
//	public String createSql() {
//		CriteriaBuilder cb = em.getCriteriaBuilder();
//		CriteriaQuery<Trade> cQuery = cb.createQuery(Trade.class);
//		Root<Trade> c = cQuery.from(Trade.class);
//		ParameterExpression<String> paramNumber = cb.parameter(String.class);
//		cQuery.select(c).where(cb.equal(c.get(Employee_.empNumber), paramEmpNumber));
//       
//      TypedQuery<Employee> query = em.createQuery(cQuery);
//      String empNumber = "A123";
//      query.setParameter(paramEmpNumber, empNumber);
//      Employee employee = query.getResultList();
//	}
	@SuppressWarnings("unchecked")
    public List<Trade> findByProduct(String product) {
		em= entityManagerFactory.createEntityManager();
        List<Trade> trades = em.createNamedQuery("Trade.findByProduct")
        		.setParameter("product", product)
                .getResultList();
        em.close();
		return trades;
    }
	@SuppressWarnings("unchecked")
	public List<Trade> findByParams(String portfolio,String col) {
		em= entityManagerFactory.createEntityManager();
        List<Trade> trades = em.createQuery(
        		"SELECT c FROM Trade c WHERE "+portfolio + " order by " + col).
        		getResultList();
        em.close();
		return trades;
	}
	@SuppressWarnings("unchecked")
	public List<Trade> runQuery(String portfolio,String grouping) {
		em= entityManagerFactory.createEntityManager();

//		CriteriaQuery<Country> q = cb.createQuery(Country.class);
//		  Root<Country> c = q.from(Country.class);
//		  q.multiselect(c.get("currency"), cb.sum(c.get("population")));
//		  q.where(cb.isMember("Europe", c.get("continents")));
//		  q.groupBy(c.get("currency"));
//		  g.having(cb.gt(cb.count(c), 1));
        List<Trade> trades = em.createQuery(
        		"SELECT c FROM Trade c WHERE "+portfolio + " GROUP BY " + grouping).
        		getResultList();
        trades.forEach(System.out::println);
        em.close();
		return trades;
	}
	@SuppressWarnings("unchecked")
	public List<Trade> runQuery1(String portfolio,String grouping) {
		em= entityManagerFactory.createEntityManager();

		CriteriaBuilder cb= em.getCriteriaBuilder();
		CriteriaQuery<Trade> q = cb.createQuery(Trade.class);
		Root<Trade> c = q.from(Trade.class);
		q.multiselect(c.get("product"),c.get("portfolio"), cb.sum(c.get("currentValue")));
		
		//q.where(((cb.in("Aggressive","Defensive"), c<String>.get("portfolio")));
		q.groupBy(c.get("portfolio"));
		//g.having(cb.gt(cb.count(c), 1));
        List<Trade> trades = em.createQuery(q).
        		getResultList();
        trades.forEach(System.out::println);
        em.close();
		return trades;
	}
	
//	public String createSql(EnterpriseGetRowsRequest request, String tableName, Map<String, List<String>> pivotValues) {
//		CriteriaBuilder cb = EntityManager.getCriteriaBuilder();
//        
//        CriteriaQuery<Employee> cQuery = cb.createQuery(Employee.class);
//        Root<Employee> c = cQuery.from(Employee.class);
//        ParameterExpression<String> paramEmpNumber = cb.parameter(String.class);
//        cQuery.select(c).where(cb.equal(c.get(Employee_.empNumber), paramEmpNumber));
//         
//        TypedQuery<Employee> query = em.createQuery(cQuery);
//        String empNumber = "A123";
//        query.setParameter(paramEmpNumber, empNumber);
//        Employee employee = query.getResultList();
//        this.valueColumns = request.getValueCols();
//        this.pivotColumns = request.getPivotCols();
//        this.groupKeys = request.getGroupKeys();
//        this.rowGroupCols = request.getRowGroupCols();
//        this.pivotValues = pivotValues;
//        this.isPivotMode = request.isPivotMode();
//        this.rowGroups = getRowGroups();
//        this.rowGroupsToInclude = getRowGroupsToInclude();
//        this.isGrouping = rowGroups.size() > groupKeys.size();
//        this.filterModel = request.getFilterModel();
//        this.sortModel = request.getSortModel();
//        this.startRow = request.getStartRow();
//        this.endRow = request.getEndRow();
//
//        return selectSql() + fromSql(tableName) + whereSql() + groupBySql() + orderBySql() + limitSql();
//        
//        CriteriaBuilder cb = em.getCriteriaBuilder();
//        
//        CriteriaQuery<Employee> cQuery = cb.createQuery(Employee.class);
//        Root<Employee> c = cQuery.from(Employee.class);
//        ParameterExpression<String> paramEmpNumber = cb.parameter(String.class);
//        cQuery.select(c).where(cb.equal(c.get(Employee_.empNumber), paramEmpNumber));
//         
//        TypedQuery<Employee> query = em.createQuery(cQuery);
//        String empNumber = "A123";
//        query.setParameter(paramEmpNumber, empNumber);
//        Employee employee = query.getResultList();
//    }
}
