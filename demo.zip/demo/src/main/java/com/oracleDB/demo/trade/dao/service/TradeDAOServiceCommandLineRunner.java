package com.oracleDB.demo.trade.dao.service;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;
import com.oracleDB.demo.trade.dao.TradeRepository;
import com.oracleDB.demo.trade.entity.Trade;

@Component
public class TradeDAOServiceCommandLineRunner implements CommandLineRunner {
	private static final Logger log =LoggerFactory.getLogger(TradeDAOServiceCommandLineRunner.class);
	
	@Autowired
	private TradeDAOService tradeDAOService;
	@Autowired
	private TradeRepository tradeRepository;
	
	@PersistenceContext
	private EntityManager em;
//	public String createSql() {
//		CriteriaBuilder cb = em.getCriteriaBuilder();
//		CriteriaQuery<Trade> cQuery = cb.createQuery(Trade.class);
//		Root<Trade> c = cQuery.from(Trade.class);
//		ParameterExpression<String> paramNumber = cb.parameter(String.class);
//		cQuery.select(c).where(cb.equal(c.get(Trade.id), paramNumber));
//       
//      TypedQuery<Trade> query = em.createQuery(cQuery);
//      String empNumber = "A123";
//      query.setParameter(paramNumber, empNumber);
//      Trade employee = (Trade) query.getResultList();
//	}
	
	@Override
	public void run(String... args) throws Exception {
		log.info("userService Run");
		List<Trade> trades= tradeRepository.findAll();
		log.info("users:" + trades);
		
		List<Trade> trades1= tradeDAOService.findByParams("c.portfolio in ('Aggressive','Defensive')","c.id desc");
		
		log.info("users:" + trades1);
		
		List<Trade> trades2= tradeDAOService.runQuery("c.portfolio in ('Aggressive','Defensive')","c.dealType");
		log.info("users:" + trades2);
	}
	
//	public String createSql(EnterpriseGetRowsRequest request, String tableName, Map<String, List<String>> pivotValues) {
//		CriteriaBuilder cb = EntityManager.getCriteriaBuilder();
//        
//        CriteriaQuery<Employee> cQuery = cb.createQuery(Employee.class);
//        Root<Employee> c = cQuery.from(Employee.class);
//        ParameterExpression<String> paramEmpNumber = cb.parameter(String.class);
//        cQuery.select(c).where(cb.equal(c.get(Employee_.empNumber), paramEmpNumber));
//         
//        TypedQuery<Employee> query = em.createQuery(cQuery);
//        String empNumber = "A123";
//        query.setParameter(paramEmpNumber, empNumber);
//        Employee employee = query.getResultList();
//        this.valueColumns = request.getValueCols();
//        this.pivotColumns = request.getPivotCols();
//        this.groupKeys = request.getGroupKeys();
//        this.rowGroupCols = request.getRowGroupCols();
//        this.pivotValues = pivotValues;
//        this.isPivotMode = request.isPivotMode();
//        this.rowGroups = getRowGroups();
//        this.rowGroupsToInclude = getRowGroupsToInclude();
//        this.isGrouping = rowGroups.size() > groupKeys.size();
//        this.filterModel = request.getFilterModel();
//        this.sortModel = request.getSortModel();
//        this.startRow = request.getStartRow();
//        this.endRow = request.getEndRow();
//
//        return selectSql() + fromSql(tableName) + whereSql() + groupBySql() + orderBySql() + limitSql();
//        
//        CriteriaBuilder cb = em.getCriteriaBuilder();
//        
//        CriteriaQuery<Employee> cQuery = cb.createQuery(Employee.class);
//        Root<Employee> c = cQuery.from(Employee.class);
//        ParameterExpression<String> paramEmpNumber = cb.parameter(String.class);
//        cQuery.select(c).where(cb.equal(c.get(Employee_.empNumber), paramEmpNumber));
//         
//        TypedQuery<Employee> query = em.createQuery(cQuery);
//        String empNumber = "A123";
//        query.setParameter(paramEmpNumber, empNumber);
//        Employee employee = query.getResultList();
//    }
}
