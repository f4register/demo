package com.oracleDB.demo.trade.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

import com.oracleDB.demo.trade.entity.Trade;

@RepositoryRestResource(collectionResourceRel = "trade", path = "trade")
public interface TradeRepository extends JpaRepository<Trade, Long> {
//	public String createSql(EnterpriseGetRowsRequest request, String tableName, Map<String, List<String>> pivotValues) {
//		CriteriaBuilder cb = EntityManager.getCriteriaBuilder();
//        
//        CriteriaQuery<Employee> cQuery = cb.createQuery(Employee.class);
//        Root<Employee> c = cQuery.from(Employee.class);
//        ParameterExpression<String> paramEmpNumber = cb.parameter(String.class);
//        cQuery.select(c).where(cb.equal(c.get(Employee_.empNumber), paramEmpNumber));
//         
//        TypedQuery<Employee> query = em.createQuery(cQuery);
//        String empNumber = "A123";
//        query.setParameter(paramEmpNumber, empNumber);
//        Employee employee = query.getResultList();
//        this.valueColumns = request.getValueCols();
//        this.pivotColumns = request.getPivotCols();
//        this.groupKeys = request.getGroupKeys();
//        this.rowGroupCols = request.getRowGroupCols();
//        this.pivotValues = pivotValues;
//        this.isPivotMode = request.isPivotMode();
//        this.rowGroups = getRowGroups();
//        this.rowGroupsToInclude = getRowGroupsToInclude();
//        this.isGrouping = rowGroups.size() > groupKeys.size();
//        this.filterModel = request.getFilterModel();
//        this.sortModel = request.getSortModel();
//        this.startRow = request.getStartRow();
//        this.endRow = request.getEndRow();
//
//        return selectSql() + fromSql(tableName) + whereSql() + groupBySql() + orderBySql() + limitSql();
//        
//        CriteriaBuilder cb = em.getCriteriaBuilder();
//        
//        CriteriaQuery<Employee> cQuery = cb.createQuery(Employee.class);
//        Root<Employee> c = cQuery.from(Employee.class);
//        ParameterExpression<String> paramEmpNumber = cb.parameter(String.class);
//        cQuery.select(c).where(cb.equal(c.get(Employee_.empNumber), paramEmpNumber));
//         
//        TypedQuery<Employee> query = em.createQuery(cQuery);
//        String empNumber = "A123";
//        query.setParameter(paramEmpNumber, empNumber);
//        Employee employee = query.getResultList();
//    }
}
