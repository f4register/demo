package com.oracleDB.demo.trade.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import lombok.Data;

/*CREATE TABLE trade
(
    product VARCHAR(255),
    portfolio VARCHAR(255),
    book VARCHAR(255),
    tradeId NUMBER,
    submitterId NUMBER,
    submitterDealId NUMBER,
    dealType VARCHAR(255),
    bidType VARCHAR(255),
    currentValue NUMBER,
    previousValue NUMBER,
    pl1 NUMBER,
    pl2 NUMBER,
    gainDx NUMBER,
    sxPx NUMBER,
    x99Out NUMBER,
    batch NUMBER
);
*/
@Entity
@Table(name="trade")
@Data
@NamedQueries({
    @NamedQuery(name="Trade.findAll",
                query="SELECT c FROM Trade c"),
    @NamedQuery(name="Trade.findByProduct",
                query="SELECT c FROM Trade c WHERE c.product = :product"),
    @NamedQuery(name="Trade.findByParams",
    query="SELECT c FROM Trade c WHERE c.portfolio = :portfolio order by :column")
}) 
public class Trade {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="trade_id")
	public Long id;
	//(product, portfolio, tradeId, book, submitterId, submitterDealId, dealType, bidType, currentValue, previousValue)

	@Column(name="product")
	private String product;
	
	@Column(name="portfolio")
	private String portfolio;
	
	@Column(name="book")
    private Integer book;
	
	@Column(name="submitter_id")
    private Long submitterId;
	
	@Column(name="submitter_deal_id")
    private Long submitterDealId;
	
	@Column(name="deal_type")
    private String dealType;
	
	@Column(name="bid_type")
    private String bidType;
	
	@Column(name="current_value")
    private double currentValue ;
	
	@Column(name="previous_value")
    private double previousValue ;	
}
