package com.oracleDB.demo.configuration;

import org.springframework.context.annotation.Configuration;
import org.springframework.data.rest.core.config.RepositoryRestConfiguration;
//import org.springframework.data.rest.webmvc.config.RepositoryRestConfigurer;
import org.springframework.http.HttpMethod;

import com.oracleDB.demo.trade.entity.Trade;

@Configuration
public class DataDemoConfig{// implements RepositoryRestConfigurer {

//	@Override
//	public void configureRepositoryRestConfiguration(RepositoryRestConfiguration config) {
//		HttpMethod[] theUnsupportedActions= {HttpMethod.PUT,HttpMethod.POST};
//		config.getExposureConfiguration().forDomainType(Trade.class)
//		.withItemExposure((metadata,httpMethods)->httpMethods.disable(theUnsupportedActions))
//		.withCollectionExposure((metadata,httpMethods)->httpMethods.disable(theUnsupportedActions));
//	}
}
